
 


DROP TABLE IF EXISTS login;
CREATE TABLE `login` (
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `access` varchar(2) NOT NULL,
  `date` varchar(10) NOT NULL
);
DROP TABLE IF EXISTS register;
CREATE TABLE `register` (
  `email` varchar(30) NOT NULL,
  `empid` varchar(10) NOT NULL,
  `empname` varchar(20) NOT NULL,
  `mangname` varchar(20) NOT NULL,
  `pass` varchar(30) NOT NULL
);

DROP TABLE IF EXISTS requestdata;
CREATE TABLE `requestdata` (
  `email` varchar(30) NOT NULL,
  `empid` varchar(10) NOT NULL,
  `empname` varchar(20) NOT NULL,
  `project` varchar(30) NOT NULL,
  `odc` varchar(30) NOT NULL,
  `date` varchar(10) NOT NULL,
  `status` varchar(1) NOT NULL
);