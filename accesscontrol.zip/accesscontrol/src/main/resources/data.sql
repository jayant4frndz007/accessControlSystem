

  
 INSERT INTO `login` (`username`, `password`, `access`, `date`) VALUES
('roger@wipro.ocm', 'wipro@123', 'a', '26/10/2018'),
('admin@wipro.com', 'admin@123', 'a', '26/10/2018');
