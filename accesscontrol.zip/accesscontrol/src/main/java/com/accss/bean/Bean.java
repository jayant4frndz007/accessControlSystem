package com.accss.bean;


public class Bean {
 
 
 private String Email;
 private String Emp_Name;
 private String Emp_id;
 private String proj_name;
 private String odc_name;
 private String joiningdate;
 private String status;
 
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public String getEmail() {
	return Email;
}
public void setEmail(String email) {
	Email = email;
}
public String getEmp_Name() {
	return Emp_Name;
}
public void setEmp_Name(String emp_Name) {
	Emp_Name = emp_Name;
}
public String getEmp_id() {
	return Emp_id;
}
public void setEmp_id(String emp_id) {
	Emp_id = emp_id;
}
public String getProj_name() {
	return proj_name;
}
public void setProj_name(String proj_name) {
	this.proj_name = proj_name;
}
public String getOdc_name() {
	return odc_name;
}
public void setOdc_name(String odc_name) {
	this.odc_name = odc_name;
}
public String getJoiningdate() {
	return joiningdate;
}
public void setJoiningdate(String joiningdate) {
	this.joiningdate = joiningdate;
}
 
 
 
 

}

