package com.accss.dbutility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DBUtility {
	 
	public static Connection getDBConnection() {
		Connection con=null;
    	try {
			Class.forName("org.h2.Driver");
			try {
				con=DriverManager.getConnection("jdbc:h2:~/mydb3","sa","admin");
				System.out.println(con);
				return con;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
    	
    
	}
}
