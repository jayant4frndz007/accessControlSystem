package com.accss.bo;

import com.accss.dao.AccessDao;

public class AccessBo {
	AccessDao dao=new AccessDao();
	public String getData() {
		// TODO Auto-generated method stub
		return dao.getData();
	}
	public String validateLogin(String user, String pass) {
		// TODO Auto-generated method stub
		return dao.validateLogin(user,pass);
	}
	public String validateRegister(String email, String empid, String empname, String mngname, String pass) {
		// TODO Auto-generated method stub
		return dao.validateRegister(email,empid,empname,mngname,pass);
	}
	public String getDataForCreate(String mail) {
		// TODO Auto-generated method stub
		return dao.getDataForCreate(mail);
	}
	public String createRequestData(String email, String empid, String empname, String project, String odc,
			String joining) {
		// TODO Auto-generated method stub
		return dao.createRequestData(email,empid,empname,project,odc,joining);
	}
	public String trackRequest(String empid) {
		// TODO Auto-generated method stub
		return dao.trackRequest(empid);
	}
	public String manageRequest() {
		// TODO Auto-generated method stub
		return dao.manageRequest();
	}
	public String approveDeny(String empid, String action) {
		// TODO Auto-generated method stub
		return dao.approveDeny( empid,  action);
	}
	

}
